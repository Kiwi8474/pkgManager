import random

def hangman():
    words = ["python", "program", "package", "manager"]
    word = random.choice(words)
    guessed = set()
    tries = 11

    while tries > 0:
        display = " ".join([c if c in guessed else "_" for c in word])
        print(display)
        if all(c in guessed for c in word):
            print("You won!")
            return
        guess = input("Guess a letter: ").lower()
        if guess in word:
            guessed.add(guess)
        else:
            tries -= 1
            print(f"Wrong! {tries} tries left.")

    print(f"You lost! The word was {word}.")

if __name__ == "__main__":
    hangman()
