import sys

while True:
    userInput = input("> ")

    if userInput == "q":
        print("\033[A \033[A")
        break