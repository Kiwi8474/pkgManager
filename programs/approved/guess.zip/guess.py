import random

number = random.randint(1,10)
while True:

    userInput = int(input("Guess a number 1-10: "))
    if userInput == number:
        print(f"You found the number!\nIt was {number}!")
        break
    else:
        print("Try again!")