import sys

while True:
    userInput = input("> ")

    if userInput == "q":
        sys.stdout.write('\x1b[1A')
        sys.stdout.write('\x1b[2K')
        sys.stdout.flush()
        break