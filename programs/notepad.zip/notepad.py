while True:
    userInput = input("> ")

    if userInput == "q":
        break